using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PotionType : MonoBehaviour
{
    public ItemData potionData;
    public SpriteRenderer spriteRenderer;
    private void Start()
    {
        Debug.Log(potionData.Tooltip);
        spriteRenderer.sprite = potionData.IconSprite;
    }

}
