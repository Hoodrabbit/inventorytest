using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGenerator : MonoBehaviour
{
    [Tooltip("�ȳ��ϼ���")]
    [SerializeField]ItemData[] item;
    public GameObject potion_prefab;
    // Start is called before the first frame update
    void Start()
    {
        Instantiate(potion_prefab).GetComponent<PotionType>().potionData = item[0];
        Instantiate(potion_prefab, new Vector2(0, 5),Quaternion.identity).GetComponent<PotionType>().potionData = item[1];

        //GameObject gamegame = new GameObject
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
