using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotateTower : MonoBehaviour
{
    Vector3 aa;
    float TTIme = 0f;
    bool rotate = false;


    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(transform.rotation.eulerAngles.x);

        aa = new Vector3(transform.rotation.eulerAngles.x + 180, 0, 0);
        
        Debug.Log(aa.x);
        Debug.Log((int)aa.x - 360);
    }

    // Update is called once per frame
    void Update()
    {
        if (rotate == false)
        {
            transform.rotation = Quaternion.Euler(aa);
            rotate = true;
        }
        else
        {
            TTIme += Time.deltaTime;
            if (TTIme > 5f)
            {
                TTIme = 0f;
                aa = new Vector3(transform.rotation.eulerAngles.x + 180, 0, 0);
                rotate = false;

            }
        }

        //aa = new Vector3(0, transform.position.y + 180, 0);


    }
}
