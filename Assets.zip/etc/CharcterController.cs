using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharcterController : MonoBehaviour
{
    public KeyCode keycode;
    public KeyCode keycode2;
    Rigidbody rb;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(keycode))
        {
            transform.Translate(Vector3.left*3 * Time.deltaTime);
        }

        if (Input.GetKey(keycode2))
        {
            transform.Translate(Vector3.right * 3 * Time.deltaTime);
        }


        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector3.up * 5, ForceMode.Impulse);
        }

    }
}
